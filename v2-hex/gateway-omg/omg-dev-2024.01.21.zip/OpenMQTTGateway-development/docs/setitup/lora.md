# LoRa gateway
## Compatible parts
An ESP32 board with a LoRa module.
Ideally a TTGO board with LoRa module included see [compatible parts list](https://compatible.openmqttgateway.com/index.php/parts)

With this kind of board there is no hardware modification needed.
